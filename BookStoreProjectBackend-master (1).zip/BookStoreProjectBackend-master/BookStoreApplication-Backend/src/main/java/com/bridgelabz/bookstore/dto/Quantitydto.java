package com.bridgelabz.bookstore.dto;

public class Quantitydto 
{

}
